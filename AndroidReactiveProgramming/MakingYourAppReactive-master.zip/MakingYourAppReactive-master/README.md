# MakingYourAppReactive
A demo app that shows how to implement RxJava and MVVM.

# Notice 
If you wish to use this code in your own project, please change the client id in NetInterceptor to use your own value. You must use your own Imgur client id in order to access Imgur's API.
