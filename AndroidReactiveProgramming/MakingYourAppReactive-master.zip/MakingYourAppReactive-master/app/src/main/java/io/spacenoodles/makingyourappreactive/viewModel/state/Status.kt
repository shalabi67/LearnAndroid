package io.spacenoodles.makingyourappreactive.viewModel.state

enum class Status {
    LOADING,
    SUCCESS,
    COMPLETE,
    TOO_SHORT,
    ERROR
}