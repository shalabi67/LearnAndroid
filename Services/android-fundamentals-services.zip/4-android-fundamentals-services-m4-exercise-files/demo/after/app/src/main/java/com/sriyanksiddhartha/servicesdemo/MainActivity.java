package com.sriyanksiddhartha.servicesdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

/**
 *
 * 	Author: Sriyank Siddhartha
 *
 * 	Module 4: "Creating IntentService"
 *
 * 			"AFTER" project
 * */
public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void startStartedService(View view) {

		Intent intent = new Intent(MainActivity.this, MyStartedService.class);
		intent.putExtra("sleepTime", 10);
		startService(intent);
	}

	public void stopStartedService(View view) {

		Intent intent = new Intent(MainActivity.this, MyStartedService.class);
		stopService(intent);
	}

	public void startIntentService(View view) {

		Intent intent = new Intent(this, MyIntentService.class);
		intent.putExtra("sleepTime", 10);
		startService(intent);
	}
}
