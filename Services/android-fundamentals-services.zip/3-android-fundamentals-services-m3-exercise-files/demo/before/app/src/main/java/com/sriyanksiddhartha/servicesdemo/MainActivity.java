package com.sriyanksiddhartha.servicesdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 *
 * 	Author: Sriyank Siddhartha
 *
 * 	Module 3: "Working with Started Service"
 *
 * 			"BEFORE" project
 * */
public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void startStartedService(View view) {

	}

	public void stopStartedService(View view) {

	}
}
