package com.sriyanksiddhartha.toolbaractionbar;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Author: Sriyank Siddhartha
 * Module 3 : Adding Toolbar
 *
 *		"BEFORE" demo project of : TOOLBAR as ACTIONBAR
 **/
public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	}
}
